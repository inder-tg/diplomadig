#' Plot methods for \code{sephora}
#'
#' Methods associated with \code{\link[sephora]{sephora-class}}.
#'
#' @name sephora-methods
#' @rdname sephora-methods
#' @aliases sephora-methods
#' @include sephora-class.R
#' @importFrom methods setMethod
#'
NULL
