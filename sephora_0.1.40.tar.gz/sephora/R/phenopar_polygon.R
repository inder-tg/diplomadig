#' Phenological parameter estimation in mass
#' 
#' Estimation of phenological parameters on a set of numeric vectors via parallel computing. 
#'
#' @param               path character with full path of RData file containing numeric vectors to analyze.
#' @param            product character specifying whether dataset is the \code{MOD13Q1} product (default) or 
#'                           a different one (\code{independent}).
#' @param               data matrix with dataset to analyze. Pertinent when \code{product="independent"} only.                           
#' @param          frequency integer giving number of observations per season. Default, 23.
#' @param             method character. Should \code{OLS} or \code{WLS} be used for smoothing each
#'                           numeric vector in analyzed dataset?
#' @param           save_all logic. Should all output objects be saved? Default is \code{FALSE}. 
#' @param          save_some character vector giving the names of the output objects that should be
#'                           saved. See \bold{Details}.                            
#' @param              sigma numeric vector of length equal to \code{frequency}. Each entry gives the 
#'                           standard deviation of observations acquired at same day of the year. 
#'                           Pertinent when \code{method=WLS}.
#' @param            numFreq integer specifying number of frequencies to use in harmonic regression
#'                           model.
#' @param              delta numeric. Default, 0. When regression problem is ill-posed, this
#'                           parameter allows a simple regularization.
#' @param           distance character indicating what distance to use in hierarchical clustering.
#'                           All distances in \code{\link[dtwclust]{tsclust}} are allowed.
#' @param        clusterSize numeric, preferably an integer, indicating the minimal number of times series
#'                           that are allowed to be part of the dominating cluster.
#' @param              basis list giving numeric basis used in FPCA-based regression. See \bold{Details}.                           
#' @param            samples integer with number of samples to draw from smoothed version of numeric
#'                           vector to analyze. Used exclusively in Functional Principal Components Analysis (FPCA)-based
#'                           regression.
#' @param               corr Default \code{NULL}. Object defining correlation structure, can be
#'                           numeric vector, matrix or function.
#' @param                  k integer, number of principal components used in FPCA-based regression.
#' @param              trace logical. If \code{TRUE}, progress on the hierarchical clustering
#'                           is printed on console. Default, \code{FALSE}.
#' @param           numCores integer. How many processing cores can be used?
#' @param          dirToSave character. In which directory to save analysis results?
#' @param reportFileBaseName character. What base name should be given to a progress report file? 
#'                           Default, \code{phenopar_progress}.
#' @param outputFileBaseName character. What base name should be given to the output file? 
#'                           Default, \code{polygon}.                            
#'
#' @export
#' 
#' @details \code{save_some} must be a subset of the valid output objects: \code{c("x", "freq", "sigma",
#' "m_aug_smooth", "clustering", "clusterSize", "fpca", "fpca_harmfit_params","fpca_fun_0der", 
#' "fpca_fun_1der", "fpca_fun_2der", "fpca_fun_3der", "fpca_fun_4der", "phenoparams","status")}.
#' 
#' Parameter \code{basis} can be supplied by a call to \code{\link[eBsc]{drbasis}}
#' with parameters \code{nn=samples} and \code{qq=2}. 
#'
#' @importFrom doParallel registerDoParallel
#' @importFrom foreach foreach
#' @importFrom foreach %dopar%
#' @importFrom parallel stopCluster
#' @importFrom utils globalVariables
#' @importFrom dtwclust tsclust
#' @importFrom geoTS haRmonics
#' @importFrom geoTS hetervar
#' @importFrom eBsc drbasis
#' @importFrom rootSolve uniroot.all
#'
#' @examples 
#' \dontrun{
#' dirOUTPUT <- system.file("data", package = "sephora")
#' BASIS <- drbasis(n=100, q=2)
#' 
#' polygon_deciduous <- deciduous_polygon
#' for(i in 1:nrow(polygon_deciduous)){
#'   polygon_deciduous[i,] <- vecFromData(data=deciduous_polygon, numRow=i)$vec
#' }
#' 
#' # --- In the following example 'numCores=2' for CRAN
#' # --- testing purposes only. In a real life example
#' # --- users are encouraged to set 'numCores' to a number
#' # --- that reflects the size of their data set as well
#' # --- as the number of available cores
#' 
#' phenopar_polygon(product="independent",
#'                  data=polygon_deciduous,
#'                  save_some=c("clustering", "phenoparams"),
#'                  numFreq = 3, distance = "dtw2",
#'                  clusterSize=14,
#'                  basis=BASIS, samples=100, 
#'                  k=3, numCores=2,
#'                  dirToSave=dirOUTPUT,
#'                  outputFileBaseName = "deciduous")
#'                  
#' # --- colors used in spiralPlot below
#' cgu <- rgb(173/255,221/255,142/255)
#' csos <- rgb(120/255,198/255,121/255)
#' cmat <- rgb(49/255, 163/255,84/255)
#' csen <- rgb(217/255, 95/255, 14/255)
#' ceos <- rgb(254/255, 153/255, 41/255)
#' cdor <- rgb(208/255, 209/255, 230/255)
#' 
#' colores <- c(cgu,csos,cmat,csen,ceos,cdor)
#' 
#' # --- How to get a spiralPlot?
#' # --- First, get 'phenoparams' object from RData file saved
#' # --- at dirOUTPUT
#' 
#' listRDatas <- list.files(path=dirOUTPUT,
#'                          pattern=".RData",
#'                          full.names=TRUE)
#'                          
#' deciduous_params <- extract_sephora(file=listRDatas[1], object="phenoparams")
#' 
#' # --- Then call getSpiralPlot()
#' getSpiralPlot(MAT=deciduous_params, 
#'               LABELS=month.name,
#'               vp_param=list(width=0.5, height=0.7))
#' vcd::grid_legend(x=1.215, y=0.125, pch=18, col=colores,
#'                 frame=FALSE,
#'                 labels=c("GU","SoS","Mat","Sen","EoS","Dor"),
#'                 title="Params")
#'             
#' # --- cleaning up after work
#' unlink(paste0(dirOUTPUT, "/deciduous_phenoParams.RData"))
#' unlink(paste0(dirOUTPUT, "/phenopar_progress.txt"))}
#'
#' @return At the location specified by \code{dirToSave}, a file containing a matrix
#' with \code{nrow} equal to the number of numeric vectors analyzed and 6 columns, is saved. 
#' When \code{path} is provided, the name of this file is:
#' 
#' \code{paste0(tools::file_path_sans_ext(basename(path)), "_phenoparams.RData")}.
#'
#' When \code{data} is provided, the name of the output file is:
#' 
#' \code{paste0(outputFileBaseName, "_phenoParams.RData"))}.
#'
#' @seealso \code{\link[sephora]{phenopar}}, \code{\link[sephora]{getSpiralPlot}}, 
#' \code{\link[dtwclust]{tsclust}}, \code{\link[sephora]{extract_sephora}}.
#'
phenopar_polygon <- function(path=NULL, product=c("MOD13Q1", "independent"), data,
                             frequency=23, method=c("OLS", "WLS"), 
                             save_all=FALSE, save_some, 
                             sigma=NULL, numFreq, delta=0, distance, clusterSize, 
                             basis, samples, corr=NULL,
                             k, trace=FALSE, numCores=20, dirToSave,
                             reportFileBaseName="phenopar_progress",
                             outputFileBaseName="polygon"){
  
  product <- match.arg(product)
  if(product == "MOD13Q1"){
    if(is.null(path)){
      stop('path must be provided')
    }
    
    dataEnv <- LoadToEnvironment(RData=path)
    data <- get(x="poly", envir=dataEnv)[[1]]
    
  } else {
    if(missing(data)){
      stop('data must be provided')
    }
  }
  
  method <- match.arg(method)
  
  if(save_all){
    objectsToSave <- validObjects
  } else {
    if(missing(save_some)){
      stop("save_some must provided")
    } else {
      toExtract <- intersect(x=validObjects, y=save_some)
      objectsToSave <- toExtract
    }
  }
  
  if(missing(numFreq)){
    stop("numFreq must provided")
  }
  
  if(missing(distance)){
    stop("distance must provided")
  }
  
  if(missing(clusterSize)){
    stop("clusterSize must provided")
  }
  
  if(missing(basis)){
    stop("basis must provided")
  }
  
  if(missing(samples)){
    if(missing(basis)){
      stop("samples must provided")
    } else {
      samples <- length(basis[["x"]])
    }
  } else {
    if(samples != length(basis[["x"]])){
      
    }
  }
  
  if(missing(k)){
    stop("k must be provided")
  }
  
  if(missing(dirToSave)){
    stop('dirToSave must be provided')
  }
  
  output <- phenopar_polygon_auxiliar(data=data, product=product, frequency=frequency, method=method,
                                      sigma=sigma, numFreq=numFreq, delta=delta, distance=distance, 
                                      clusterSize=clusterSize,
                                      samples=samples, basis=basis, corr=corr, k=k, trace=trace,
                                      numCores=numCores, 
                                      objectsToSave=objectsToSave,
                                      dirToSave=dirToSave, 
                                      reportFileBaseName=reportFileBaseName)
  
  
  save(output, file = paste0(dirToSave, "/",
                             ifelse( !is.null(path), 
                                     tools::file_path_sans_ext(basename(path)), 
                                     outputFileBaseName ),
                             "_phenoParams.RData"))
  
}
