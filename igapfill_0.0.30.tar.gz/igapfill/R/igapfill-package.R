#' Interface for Gapfilling Earth Observation Datasets
#' 
#' The main functions of this package facilitate the application of the spatio-temporal
#' gap-filling method \code{\link[gapfill]{Gapfill}} to sets of satellite images making
#' extensive use of parallel computing. 
#' 
#' @details 
#' 
#' Only \emph{GeoTiff} files, see \code{\link[raster]{writeRaster}}
#' for further details on this format, are allowed. In passing, some of the functions
#' of this package can be construed as independent builders of arguments used by \code{\link[gapfill]{Gapfill}}.
#' 
#' @name igapfill-package
#' @author Tecuapetla-Gómez, I. \email{itecuapetla@@conabio.gob.mx}
#' 
#' @section Quality assessment summary: 
#' 
#' The following functions allow to compute the amount of missing values in a time
#' series of satellite images and to determine a sub-set of images that are candidates
#' to undergo the workflow of this package.
#' 
#' \tabular{ll}{
#'  \code{\link{mvSieve}}\tab Computes amount of missing values in a time series images \cr
#'  \code{\link{sieveMinBlock}}\tab Determines sub-set of images with minimum missing values \cr
#' } 
#' 
#' @section Workflow:
#' 
#' The following functions allow to define the required directory/folders
#' structure employed by this package. Some of these functions are also useful
#' for better data handling.
#' 
#' \tabular{ll}{
#'   \code{\link{create_dirs}}\tab Sets up directory tree \cr
#'   \code{\link{dimsReport}}\tab Summary of dimensions of images to process \cr
#'   \code{\link{sort_split}}\tab Split large images into smaller chunks \cr
#'   \code{\link{waysToSplit}}\tab Briefing of ways to divide rows and columns of large images \cr
#'   \code{\link{split_master}}\tab Take an image (possibly with missing values) and split it into smaller chunks \cr
#' }
#' 
#' @section Interface:
#' 
#' These are the main functions of this package. Either of them allows for gap-filling
#' of sets of satellite images using \code{\link[gapfill]{Gapfill}}.
#' 
#' \tabular{ll}{
#'   \code{\link{applyGapfill}}\tab Parallel computing-based application of \code{\link[gapfill]{Gapfill}} \cr
#'   \code{\link{igapfill}}\tab Console-based wrap-up of \code{applyGapfill} \cr
#'   \code{\link{parallel_mosaic}}\tab Parallel rasterization (possibly mosaicking) of output of \code{\link[igapfill]{applyGapfill}} \cr
#' }
#' 
#' @section Miscellaneous:
#' 
#' These functions can be used to obtain some of the arguments required by \code{\link[igapfill]{applyGapfill}}.
#' In addition to this, these functions can also be employed to define some arguments of 
#' \code{\link[gapfill]{Gapfill}}.
#' 
#' \tabular{ll}{
#'   \code{\link{getListFiles}}\tab Similar to \code{\link[base]{list.files}} but with ordered output \cr
#'   \code{\link{get_3Darray}}\tab Assambles 3D array \cr
#'   \code{\link{get_4Darray}}\tab Assambles 4D array \cr
#'   \code{\link{get_LAT}}\tab Gets latitude information of RasterStack \cr
#'   \code{\link{get_LON}}\tab Gets longitude information of RasterStack \cr
#' }
#' 
#' @references Gerber, F., de Jong, R., Schaepman, M.E., Schaepman-Strub, G., Furrer, R. (2018). 
#' \emph{Predicting missing values in spatio-temporal remote sensing data}, IEEE Transactions on Geoscience 
#' and Remote Sensing, 1--13.
#' 
#' @keywords package
"_PACKAGE"