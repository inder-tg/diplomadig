#' Minimal \eqn{2 \times 2} (non-zero) matrix of missing values
#' 
#' Finds the minimum \eqn{2 \times 2} (non-zero) block within a matrix that records
#' the amount of missing values of satellite images.
#' 
#' @param sieve matrix
#' @param  rank numeric, the \eqn{n}-th largest non-zero value in \code{sieve} that 
#'              is considered in the block search.
#' 
#' @export
#' 
#' @details
#' This function searches for the minimal \eqn{2\times 2} (non-zero) sub-matrix 
#' within a \emph{general} \code{sieve} matrix. Let us define \emph{blockMissingness}
#' as \eqn{\log( cumsum (a_{i,j}) )} for \eqn{1\leq i,j\leq 2}. The minimal block is 
#' defined as that block with the minimum blockMissingness. The \code{cumsum} function 
#' is preferred rather than other quantities, such as \code{cumprod}
#' or \code{det}, because \code{sieve} could have a large amount of zeros.
#' 
#' In the first stage of the search, a vector with the sorted, non-zero,
#' values of \code{sieve} is calculated. Consider the \eqn{i}-th entry of this sorted
#' vector. This value corresponds to some (maybe more than once) cell within \code{sieve}.
#' Notice that this cell belongs to four \eqn{2\times 2} matrices. The blockMissingness
#' of each of these 4 matrices is calculated. The matrix with the smallest blockMissingness
#' is called a \emph{localMinBlock}.
#' 
#' The procedure just described is applied to each of the \code{rank} entries of the
#' sorted vector; the \emph{globalMinBlock} is that localMinBlock with the
#' smallest blockMissingness.
#' 
#' @seealso \code{\link[igapfill]{mvSieve}}
#' 
#' @return A list containing:
#' \item{rows}{a numeric vector given the rows of \code{sieve} where the minimal \eqn{2\times 2} is found.}
#' \item{cols}{a numeric vector given the cols of \code{sieve} where the minimal \eqn{2\times 2} is found.}
#' \item{block}{a \eqn{2\times 2} sub-matrix of \code{sieve},  the actual minimal block.}
#' \item{blockMissingness}{a numeric with the blockMissingness of the minimal block.}
#' 
sieveMinBlock <- function(sieve, rank=25){
  
  if( !inherits(sieve, "matrix" ) ){
    stop("sieve must be a matrix")
  }
  
  sieve_aux <- sieve
  
  sieve_aux[ sieve_aux == 0 ] <- NA
  
  sortedValues <- sort(sieve_aux)
  
  getGlobalMinBlock(sorted=sortedValues[1:rank], sieve = sieve)
}
